const express = require("express");
const app = express();
// OPTIONAL: app.use(express.static("assets"))
const HTTP_PORT = process.env.PORT || 8080;

const music = [
    { title: "Mamaw's House", artist: "Thomas Rhett", artist_image: "thomasrhett.jpg", id: 1 },
    { title: "Lil Boo Thang", artist: "Paul Russell", artist_image: "Paul-Russell.jpeg", id: 2 },
    { title: "Save Me", artist: "Jelly Roll", artist_image: "Jelly-Roll.jpeg", id: 3 },
    { title: "The Kill (Bury Me)", artist: "Thirty Seconds to Mars", artist_image: "30stomars.jpeg", id: 4 }
];

const playlist = [];
//import handlebars
app.use(express.static("./assests/artist"));
const exphbs = require('express-handlebars');
app.engine('.hbs', exphbs.engine({ extname: '.hbs' }));
app.set('view engine', '.hbs');

app.get("/", (req, res) => {
    res.render("music_list",
        { layout: false, music })
});

app.get("/playlist", (req, res) => {
    console.log("Presenting playlist.html now")

    res.render("playlist",
        { layout: false, playlist })
});

app.post("/add-song/:artistId", (req, res) => {

    const artistId = +req.params.artistId;

    // Find the song with the specified ID from the array
    const songToAdd = music.find(artist => artist.id === artistId);

    if (songToAdd) {
        // Add the song to the playlist array
        playlist.push(songToAdd);
    }
    //res.redirect() to navigate the user to another endpoint of the server
    // res.send(`Artist selected : ${req.params.artistId}`)
    res.render("playlist",
        { layout: false, playlist })
})
app.post("/delete-song/:artistId", (req, res) => {
    const songIdToDelete = +req.params.artistId;
    //checking if any songs were removed
    let songsRemoved = false;

    for (let i = playlist.length - 1; i >= 0; i--) {
        if (playlist[i].id === songIdToDelete) {
            // Remove the song at index i 
            playlist.splice(i, 1);
            songsRemoved = true;
        }
    }

    if (songsRemoved) {

        res.render("playlist",
            { layout: false, playlist })
    }
});

const onHttpStart = () => {
    console.log("The web server has started...");
    console.log(`Server is listening on port ${HTTP_PORT}`);
    console.log("Press CTRL+C to stop the server.");
};


app.listen(HTTP_PORT, onHttpStart);